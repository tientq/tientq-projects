Cach chay chuong trinh
yeu cau mysql server va java 1.7
Trong MySQL thuc hien Import co so du lieu tu file sql/sudoku.sql
Dien duong dan, user va pass truy cap vao co so du lieu vao file database.cfg
chay file sudoku.jar
(phai de file sudoku.jar cung cho voi forder data va images)

Xem ma nguon chuong trinh
Chuong trinh duoc viet tren eclipse ma hoa theo utf-8
Mo eclipse
File > Import > Existing Project into WorkSpace > next
Chon duong dan den thu muc sudoku chua ma nguon hoac file sudoku.zip
Kich chuot phai vao project sudoku chon properties > Resource > Text file encoding > UTF-8 > ok
bay gio co the run (Ctrl+F11)

Neu co bieu tuong canh bao do, co the la do su dung phien ban java duoi 1.7
khac phuc bang cach down ban java moi nhat
hoac do chuong trinh khong tim thay file sudoku_lib/mysql-connector-java-5.1.22-bin.jar
khac phuc bang cach kich chuot phai vao project sudoku > Build Path > Configure Build Path > Librarier > add JARS
chon duong dan den file mysql-connector-java-5.1.22-bin.jar > OK
(neu khong tim thay file mysql-connector-java-5.1.22-bin.jar co the lay trong file sudoku.zip)
 
